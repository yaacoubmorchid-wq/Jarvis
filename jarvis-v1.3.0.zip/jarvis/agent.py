"""The agent loop: Claude + tools, approvals, and automatic escalation by phone."""
import json
import threading
import time
import urllib.request

import config
import tools

SYSTEM = (
    "You are JARVIS, a personal AI assistant that does the owner's work on their PC: files, email, commands. "
    "Work autonomously and finish tasks. Be brief. "
    "If anything goes wrong, is risky, is ambiguous, or needs a human decision (payments, deleting data, "
    "legal or money matters, repeated errors), call the call_owner tool with a short clear reason, then stop. "
    "Never invent results; report what the tools actually returned."
)

LOCK = threading.Lock()
STATE = {"log": [], "pending": {}, "busy": False, "n": 0}
_events = {}


def log(kind, text):
    with LOCK:
        STATE["n"] += 1
        STATE["log"].append({"id": STATE["n"], "t": time.strftime("%H:%M:%S"), "kind": kind, "text": text})


def resolve(approval_id, ok):
    ev = _events.get(approval_id)
    if ev:
        ev["ok"] = ok
        ev["event"].set()


def _ask_approval(name, args):
    aid = str(int(time.time() * 1000))
    ev = {"event": threading.Event(), "ok": False}
    _events[aid] = ev
    with LOCK:
        STATE["pending"][aid] = {"id": aid, "tool": name, "args": args}
    log("approval", f"Waiting for your OK: {name} {json.dumps(args)[:200]}")
    answered = ev["event"].wait(config.APPROVAL_TIMEOUT)
    with LOCK:
        STATE["pending"].pop(aid, None)
    if not answered:
        log("escalate", "No answer in time, calling the owner")
        log("tool", tools.call_owner(f"I am waiting for your approval to run {name}. Please open Jarvis."))
        return None
    return ev["ok"]


def _exec(name, args, fails):
    fn, risky, *_ = tools.TOOLS[name]
    if risky(args):
        ok = _ask_approval(name, args)
        if ok is None:
            return "No approval received. Owner was phoned. Stop and wait."
        if not ok:
            return "The owner denied this action."
    try:
        return str(fn(**args))
    except Exception as e:  # noqa: BLE001
        fails[0] += 1
        msg = f"ERROR {type(e).__name__}: {e}"
        if fails[0] >= 3:
            log("escalate", "Three errors in a row, calling the owner")
            log("tool", tools.call_owner(f"I hit repeated errors. Last one: {msg[:200]}"))
        return msg


def _claude(messages):
    key = config.get("ANTHROPIC_API_KEY")
    body = json.dumps({"model": config.MODEL, "max_tokens": 2048, "system": SYSTEM,
                       "tools": tools.api_schema(), "messages": messages}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read())


def _demo_script(task):
    """No API key: a scripted run that shows the whole flow, including the phone call."""
    t = task.lower()
    steps = [("read_email", {}), ]
    if "email" in t or "mail" in t or "reply" in t:
        steps.append(("send_email", {"to": "supplier@example.com", "subject": "Invoice 4411",
                                     "body": "Hello, we will check the failed payment today."}))
    steps.append(("write_file", {"path": "notes.txt", "content": "Task: " + task + "\nSupplier invoice 4411 failed - needs owner."}))
    steps.append(("call_owner", {"reason": "A supplier invoice payment failed. This needs your decision."}))
    return steps


def run_task(task):
    with LOCK:
        if STATE["busy"]:
            return False
        STATE["busy"] = True
    threading.Thread(target=_run, args=(task,), daemon=True).start()
    return True


def _run(task):
    fails = [0]
    try:
        log("user", task)
        if not config.get("ANTHROPIC_API_KEY"):
            log("info", "No Anthropic key: running the built-in demo script.")
            for name, args in _demo_script(task):
                log("tool", f"{name} {json.dumps(args)[:150]}")
                log("result", _exec(name, args, fails)[:300])
            log("assistant", "Done. I handled what I could and phoned you about the failed invoice.")
            return
        messages = [{"role": "user", "content": task}]
        for _ in range(20):
            resp = _claude(messages)
            messages.append({"role": "assistant", "content": resp["content"]})
            results = []
            for block in resp["content"]:
                if block["type"] == "text" and block["text"].strip():
                    log("assistant", block["text"])
                elif block["type"] == "tool_use":
                    log("tool", f"{block['name']} {json.dumps(block['input'])[:150]}")
                    out = _exec(block["name"], block["input"], fails)
                    log("result", out[:300])
                    results.append({"type": "tool_result", "tool_use_id": block["id"], "content": out})
            if not results:
                break
            messages.append({"role": "user", "content": results})
    except Exception as e:  # noqa: BLE001
        log("escalate", f"Jarvis crashed: {e}")
        try:
            log("tool", tools.call_owner(f"I crashed while working: {str(e)[:200]}"))
        except Exception as e2:  # noqa: BLE001
            log("error", f"Could not phone: {e2}")
    finally:
        with LOCK:
            STATE["busy"] = False
