"""What Jarvis can do on the PC, by email and by phone."""
import base64
import email
import imaplib
import json
import smtplib
import subprocess
import urllib.parse
import urllib.request
from email.message import EmailMessage

import config

REAL = not config.DEMO


def _safe_path(p):
    full = (config.ROOT / p).resolve()
    if config.ROOT.resolve() not in full.parents and full != config.ROOT.resolve():
        raise PermissionError("Outside the allowed folder")
    return full


def list_dir(path="."):
    return "\n".join(sorted(x.name + ("/" if x.is_dir() else "") for x in _safe_path(path).iterdir())) or "(empty)"


def read_file(path):
    return _safe_path(path).read_text(encoding="utf-8", errors="replace")[:20000]


def write_file(path, content):
    f = _safe_path(path)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(content, encoding="utf-8")
    return f"Wrote {len(content)} characters to {path}"


def run_command(command):
    if not REAL:
        return f"[demo] would run: {command}"
    r = subprocess.run(command, shell=True, cwd=config.ROOT, capture_output=True, text=True, timeout=120)
    return (r.stdout + r.stderr)[-6000:] or "(no output)"


def read_email(limit=5):
    if not REAL:
        return ("[demo] 1) From: boss@example.com - 'Quarterly report due Monday'\n"
                "2) From: supplier@example.com - 'Invoice 4411 is overdue, payment failed'\n"
                "3) From: newsletter@example.com - 'Weekly digest'")
    m = imaplib.IMAP4_SSL(config.get("IMAP_HOST"))
    m.login(config.get("EMAIL_USER"), config.get("EMAIL_PASS"))
    m.select("INBOX")
    _, data = m.search(None, "UNSEEN")
    out = []
    for num in data[0].split()[-int(limit):]:
        _, msg = m.fetch(num, "(RFC822)")
        e = email.message_from_bytes(msg[0][1])
        out.append(f"From: {e['From']} | Subject: {e['Subject']}")
    m.logout()
    return "\n".join(out) or "No unread email"


def send_email(to, subject, body):
    if not REAL:
        return f"[demo] email NOT sent. To: {to} | Subject: {subject}"
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = config.get("EMAIL_USER"), to, subject
    msg.set_content(body)
    with smtplib.SMTP_SSL(config.get("SMTP_HOST"), int(config.get("SMTP_PORT", "465"))) as s:
        s.login(config.get("EMAIL_USER"), config.get("EMAIL_PASS"))
        s.send_message(msg)
    return f"Email sent to {to}"


def call_owner(reason):
    """Phone the owner and read the problem out loud (Twilio). In deaf mode, send an SMS instead."""
    deaf = config.SETTINGS["deaf"]
    if not REAL:
        return (f"[demo] would send the owner a text message: {reason}" if deaf
                else f"[demo] would phone the owner and say: {reason}")
    sid, tok = config.get("TWILIO_SID"), config.get("TWILIO_TOKEN")
    if deaf:
        data = urllib.parse.urlencode({"To": config.get("OWNER_PHONE"), "From": config.get("TWILIO_FROM"),
                                       "Body": "JARVIS: " + reason[:600]}).encode()
        req = urllib.request.Request(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json", data=data)
        req.add_header("Authorization", "Basic " + base64.b64encode(f"{sid}:{tok}".encode()).decode())
        with urllib.request.urlopen(req, timeout=20) as r:
            return "Text message sent: " + json.loads(r.read()).get("status", "ok")
    twiml = "<Response><Say voice='alice'>Hello, this is Jarvis. %s</Say></Response>" % (
        reason.replace("<", "").replace(">", "").replace("&", "and")[:500])
    data = urllib.parse.urlencode({"To": config.get("OWNER_PHONE"), "From": config.get("TWILIO_FROM"),
                                   "Twiml": twiml}).encode()
    req = urllib.request.Request(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Calls.json", data=data)
    req.add_header("Authorization", "Basic " + base64.b64encode(f"{sid}:{tok}".encode()).decode())
    with urllib.request.urlopen(req, timeout=20) as r:
        return "Call placed: " + json.loads(r.read()).get("status", "ok")


# name -> (function, needs_approval(args) -> bool, schema)
def _cmd_risky(a):
    c = a.get("command", "").strip()
    return not any(c == s or c.startswith(s + " ") for s in config.SAFE_COMMANDS)


TOOLS = {
    "list_dir": (list_dir, lambda a: False, "List files in a folder of the workspace.",
                 {"path": {"type": "string"}}, []),
    "read_file": (read_file, lambda a: False, "Read a text file from the workspace.",
                  {"path": {"type": "string"}}, ["path"]),
    "write_file": (write_file, lambda a: False, "Create or overwrite a file in the workspace.",
                   {"path": {"type": "string"}, "content": {"type": "string"}}, ["path", "content"]),
    "run_command": (run_command, _cmd_risky, "Run a shell command on the PC (inside the workspace).",
                    {"command": {"type": "string"}}, ["command"]),
    "read_email": (read_email, lambda a: False, "Read recent unread emails.",
                   {"limit": {"type": "integer"}}, []),
    "send_email": (send_email, lambda a: True, "Send an email. The owner approves first.",
                   {"to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"}},
                   ["to", "subject", "body"]),
    "call_owner": (call_owner, lambda a: False,
                   "Phone the owner. Use when something is wrong, risky, unclear, or needs a human decision.",
                   {"reason": {"type": "string"}}, ["reason"]),
}


def api_schema():
    return [{"name": n, "description": d,
             "input_schema": {"type": "object", "properties": props, "required": req}}
            for n, (_, _, d, props, req) in TOOLS.items()]
