"""Local server. Standard library only. API keys stay here, never in the browser."""
import hmac
import json
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import agent
import config

WEB = config.HERE / "web"
TYPES = {".html": "text/html", ".js": "text/javascript", ".css": "text/css"}
FAILS = {}  # ip -> recent wrong-code timestamps


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def _authed(self):
        """True if no code is set, or the request carries the right code. Locks out guessers."""
        if not config.ACCESS_CODE:
            return True
        ip = self.client_address[0]
        now = time.time()
        fails = [t for t in FAILS.get(ip, []) if now - t < 300]
        FAILS[ip] = fails
        if len(fails) >= 10:
            return False
        if hmac.compare_digest(self.headers.get("X-Jarvis-Code", ""), config.ACCESS_CODE):
            return True
        fails.append(now)
        return False

    def do_GET(self):
        path = urlparse(self.path).path
        if path.startswith("/api/") and not self._authed():
            return self._send(401, {"error": "access code required"})
        if path == "/api/state":
            with agent.LOCK:
                s = {"log": agent.STATE["log"][-200:], "pending": list(agent.STATE["pending"].values()),
                     "busy": agent.STATE["busy"], "demo": config.DEMO, "deaf": config.SETTINGS["deaf"],                     "has_ai_key": bool(config.get("ANTHROPIC_API_KEY")),
                     "has_voice_key": bool(config.get("FISH_API_KEY"))}
            return self._send(200, s)
        name = "index.html" if path in ("/", "") else path.lstrip("/")
        f = (WEB / name).resolve()
        if WEB.resolve() in f.parents and f.is_file():
            return self._send(200, f.read_bytes(), TYPES.get(f.suffix, "application/octet-stream"))
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._authed():
            return self._send(401, {"error": "access code required"})
        d = self._json()
        if self.path == "/api/task":
            ok = agent.run_task(d.get("text", "").strip()) if d.get("text", "").strip() else False
            return self._send(200 if ok else 409, {"ok": ok})
        if self.path == "/api/settings":
            if "deaf" in d:
                config.SETTINGS["deaf"] = bool(d["deaf"])
            return self._send(200, {"deaf": config.SETTINGS["deaf"]})
        if self.path == "/api/approve":
            agent.resolve(d.get("id"), bool(d.get("ok")))
            return self._send(200, {"ok": True})
        if self.path == "/api/tts":
            key = config.get("FISH_API_KEY")
            if not key:
                return self._send(204, b"", "text/plain")
            req = urllib.request.Request("https://api.fish.audio/v1/tts", data=json.dumps(
                {"text": d.get("text", "")[:1000], "reference_id": config.FISH_REFERENCE_ID,
                 "format": "mp3"}).encode(), headers={
                "Authorization": "Bearer " + key, "Content-Type": "application/json", "model": "s1"})
            try:
                with urllib.request.urlopen(req, timeout=40) as r:
                    return self._send(200, r.read(), "audio/mpeg")
            except Exception:  # noqa: BLE001
                return self._send(204, b"", "text/plain")
        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    host = "0.0.0.0" if config.ACCESS_CODE else "127.0.0.1"
    print(f"JARVIS on http://localhost:{config.PORT}  (demo={config.DEMO}, folder={config.ROOT})")
    if config.ACCESS_CODE:
        print("Phone access ON: listening on your network, access code required. Home Wi-Fi only, never expose to the internet.")
    ThreadingHTTPServer((host, config.PORT), H).serve_forever()
