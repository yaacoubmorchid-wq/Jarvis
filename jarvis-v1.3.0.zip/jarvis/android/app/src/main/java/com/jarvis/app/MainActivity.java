package com.jarvis.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;

/** Thin shell around the Jarvis web interface running on your PC. */
public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;
    private boolean dialogOpen = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    setup("Cannot reach Jarvis. Check the address, the access code, that your PC is on, "
                            + "and that the phone is on the same Wi-Fi.");
                }
            }
        });

        if (prefs.getString("addr", "").isEmpty()) {
            setup(null);
        } else {
            load();
        }
    }

    private void load() {
        String url = "http://" + prefs.getString("addr", "")
                + "/?code=" + Uri.encode(prefs.getString("code", ""));
        web.loadUrl(url);
    }

    private void setup(String message) {
        if (dialogOpen) return;
        dialogOpen = true;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);

        final EditText addr = new EditText(this);
        addr.setHint("PC address, e.g. 192.168.1.20:8765");
        addr.setText(prefs.getString("addr", ""));
        addr.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        box.addView(addr);

        final EditText code = new EditText(this);
        code.setHint("Access code");
        code.setText(prefs.getString("code", ""));
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(code);

        new AlertDialog.Builder(this)
                .setTitle("Connect to Jarvis")
                .setMessage(message == null
                        ? "Enter the address shown on your PC and the access code you set."
                        : message)
                .setView(box)
                .setCancelable(false)
                .setPositiveButton("Connect", (d, w) -> {
                    prefs.edit()
                            .putString("addr", addr.getText().toString().trim())
                            .putString("code", code.getText().toString().trim())
                            .apply();
                    dialogOpen = false;
                    load();
                })
                .show();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
