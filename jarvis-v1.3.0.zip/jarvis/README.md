# JARVIS

A personal AI assistant that works on your PC, handles email, and **contacts you when something is wrong**.
Python standard library only, vanilla JS, no build step. Includes an Android app that controls it from your phone.

## What it does
- Does tasks for you: reads and writes files, runs commands, reads and sends email (powered by Claude).
- Asks your approval before sending email or running anything outside a short safe list.
- Contacts you if it hits repeated errors, crashes, or you don't answer an approval in time (default 5 min).
  It phones you via Twilio, or sends a text message in deaf mode.
- Voice in and out (browser mic + Fish Audio voice), or text-only chat with flashing alerts in **deaf mode**.

## Download
Go to the **Releases** page of this repository and download:
- `Jarvis-PC.zip`: the program for your PC (opens with WinRAR, 7-Zip, or Windows Explorer).
- `Jarvis.apk`: the Android app (see "Phone app" below).

## Free
Jarvis is free and open source (MIT license). There is no paywall, no license key, and no account to sign up for.
You only pay for the services you connect to it yourself (an Anthropic key for the AI, Twilio for calls and texts).

## Quick start (PC)
1. Install Python 3.9+.
2. Unzip, then run `start.bat` (Windows) or `./start.sh` (Mac/Linux). Your browser opens at http://localhost:8765.
3. It starts in **demo mode**: nothing real is sent, nobody is called, files stay in `sample_workspace/`.

## Going live
1. Copy `jarvis.env.example` to `jarvis.env` and fill in the keys you have
   (Anthropic, Fish Audio, email app password, Twilio).
2. Set `JARVIS_ROOT` to the one folder Jarvis may touch.
3. Set `JARVIS_DEMO=0`.

## Phone app (Android)
1. On the PC, set `JARVIS_ACCESS_CODE` in `jarvis.env` (8+ characters) and restart Jarvis.
   This makes Jarvis listen on your home network, and every request needs the code.
2. Find your PC's local address (for example `192.168.1.20`). Your address is `that-address:8765`.
3. On the phone, allow installing apps from unknown sources, open `Jarvis.apk`, and install it.
4. Open the app, enter the address and the code. You can now give tasks and tap Approve or Deny from the phone.
The phone and the PC must be on the same Wi-Fi. The APK is a debug build, signed with a debug key, so it is for sideloading,
not for the Play Store.

## Safety notes
- Jarvis can run shell commands. Only run it on a computer you own, with a `JARVIS_ROOT` folder you are happy to expose.
- Review every approval prompt. Keep `JARVIS_SAFE_COMMANDS` short.
- With no access code, Jarvis listens on this PC only. With a code, it listens on your network over plain HTTP:
  use it on a Wi-Fi you trust, choose a long code, and **never forward the port to the internet**.
- Never share or commit `jarvis.env` (it is in `.gitignore`).
- Shell commands run with `shell=True` inside the folder, but the folder is not a sandbox: a command can still reach other files.
- It is a young project: expect bugs in real email and phone use.

## Building the Android app yourself
Open the `android/` folder in Android Studio, or push a tag like `v1.1.0` to GitHub and the included workflow
(`.github/workflows/build.yml`) builds `Jarvis.apk` and `Jarvis-PC.zip` and attaches them to a release.

## Files
`server.py` web server · `agent.py` agent loop and escalation · `tools.py` PC/email/phone tools ·
`config.py` settings (demo mode lives here) · `web/` interface · `android/` phone app

Version 1.3.0
