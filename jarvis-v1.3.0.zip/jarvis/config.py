"""Single place where settings are read. Demo mode is decided here only."""
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _load_env():
    f = HERE / "jarvis.env"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()


def get(key, default=""):
    return os.environ.get(key, default)


# Demo is ON unless explicitly turned off. In demo nothing real is sent,
# no real call is placed, and files live in ./sample_workspace.
DEMO = get("JARVIS_DEMO", "1") != "0"

# Deaf / hard-of-hearing mode: text chat only, no voice in or out, big visual alerts,
# and a text message (SMS) instead of a phone call. Can also be toggled in the app.
SETTINGS = {"deaf": get("JARVIS_DEAF_MODE", "0") == "1"}

# Phone/network access. With no code, Jarvis only listens on this PC (127.0.0.1).
# With a code, it also listens on your home network so the Android app can connect,
# and every request must carry the code.
ACCESS_CODE = get("JARVIS_ACCESS_CODE")

MODEL = get("JARVIS_MODEL", "claude-sonnet-5-5")
PORT = int(get("JARVIS_PORT", "8765"))
FISH_REFERENCE_ID = get("FISH_REFERENCE_ID", "14129c3e320149449d6bada6862f7338")

# The only folder Jarvis may read/write. Real folder only when demo is off.
ROOT = Path(get("JARVIS_ROOT", str(HERE / "sample_workspace"))).expanduser()
if DEMO:
    ROOT = HERE / "sample_workspace"
ROOT.mkdir(parents=True, exist_ok=True)

# Shell commands starting with these run without asking. Everything else asks you.
SAFE_COMMANDS = [c for c in get("JARVIS_SAFE_COMMANDS", "dir,ls,echo,date,whoami,python --version").split(",") if c]

# If you do not answer an approval within this time, Jarvis calls you.
APPROVAL_TIMEOUT = int(get("JARVIS_APPROVAL_TIMEOUT", "300"))
