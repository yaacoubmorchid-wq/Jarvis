const $ = (id) => document.getElementById(id);
let lastId = 0, spokenId = 0, firstLoad = true, deaf = false, seenPending = new Set();
const baseTitle = document.title;

// Access code (used when Jarvis runs with phone access). Comes from the Android app via ?code=.
let CODE = "";
try { CODE = localStorage.getItem("jcode") || ""; } catch (e) {}
const urlCode = new URLSearchParams(location.search).get("code");
if (urlCode) {
  CODE = urlCode;
  try { localStorage.setItem("jcode", CODE); } catch (e) {}
  history.replaceState(null, "", location.pathname);
}
let prompting = false;

async function api(url, opts = {}) {
  const go = () => fetch(url, { ...opts, headers: { ...(opts.headers || {}), "X-Jarvis-Code": CODE } });
  let r = await go();
  if (r.status === 401 && !prompting) {
    prompting = true;
    const c = prompt("Jarvis access code:");
    prompting = false;
    if (c) {
      CODE = c;
      try { localStorage.setItem("jcode", c); } catch (e) {}
      r = await go();
    }
  }
  return r;
}

async function post(url, body) {
  return api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
}

async function speak(text) {
  if (deaf) return; // deaf mode: never speak, everything is shown as text
  try {
    const r = await post("/api/tts", { text });
    if (r.status === 200) {
      const a = new Audio(URL.createObjectURL(await r.blob()));
      return a.play();
    }
  } catch (e) {}
  if (window.speechSynthesis) speechSynthesis.speak(new SpeechSynthesisUtterance(text));
}

function esc(s) { const d = document.createElement("div"); d.textContent = s; return d.innerHTML; }

// Visual + vibration alert, used instead of sound in deaf mode.
function alertUser(text) {
  $("alerttext").textContent = text;
  $("alert").hidden = false;
  document.title = "⚠ JARVIS needs you";
  if (navigator.vibrate) navigator.vibrate([300, 150, 300, 150, 300]);
}
$("dismiss").onclick = () => { $("alert").hidden = true; document.title = baseTitle; };

function applyDeaf(on) {
  deaf = on;
  document.body.classList.toggle("deaf", on);
  $("deaf").setAttribute("aria-pressed", String(on));
  $("deaf").textContent = "♿ Deaf mode: " + (on ? "on" : "off");
  $("mic").style.display = on || !SR ? "none" : "";
  $("text").placeholder = on ? "Type a message to Jarvis..." : "Tell Jarvis what to do...";
}

async function refresh() {
  let s;
  try {
    const r = await api("/api/state");
    if (r.status !== 200) return;
    s = await r.json();
  } catch (e) { return; }
  if (s.deaf !== deaf) applyDeaf(s.deaf);
  $("orb").className = "orb" + (s.busy ? " busy" : "");
  $("mode").textContent = s.demo ? "DEMO MODE" : "LIVE";
  $("mode").className = "badge" + (s.demo ? " demo" : "");

  $("pending").innerHTML = s.pending.map((p) =>
    `<div class="ask"><b>Jarvis needs your OK</b><code>${esc(p.tool)} ${esc(JSON.stringify(p.args, null, 1))}</code>
     <button onclick="decide('${p.id}',true)">Approve</button> <button class="no" onclick="decide('${p.id}',false)">Deny</button></div>`).join("");

  if (deaf) {
    s.pending.forEach((p) => {
      if (!seenPending.has(p.id)) { seenPending.add(p.id); alertUser("Waiting for your approval: " + p.tool); }
    });
  }

  const fresh = s.log.filter((l) => l.id > lastId);
  if (fresh.length) {
    const box = $("log");
    fresh.forEach((l) => {
      const who = l.kind === "user" ? "You" : l.kind === "assistant" ? "Jarvis" : "";
      box.insertAdjacentHTML("beforeend",
        `<div class="row ${l.kind}"><small>${who ? who + " · " : ""}${l.t}</small>${esc(l.text)}</div>`);
      lastId = l.id;
      if (!firstLoad && l.id > spokenId && (l.kind === "assistant" || l.kind === "escalate")) {
        spokenId = l.id;
        if (deaf && l.kind === "escalate") alertUser(l.text);
        speak(l.text);
      }
    });
    $("log").parentElement.scrollTop = 1e9;
  }
  firstLoad = false;
}

window.decide = (id, ok) => post("/api/approve", { id, ok }).then(refresh);

async function send() {
  const t = $("text").value.trim();
  if (!t) return;
  $("text").value = "";
  const r = await post("/api/task", { text: t });
  if (r.status === 409) alert("Jarvis is busy with another task.");  refresh();
}

$("send").onclick = send;
$("text").onkeydown = (e) => { if (e.key === "Enter") send(); };
$("deaf").onclick = () => post("/api/settings", { deaf: !deaf }).then(refresh);

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SR) {
  const rec = new SR();
  rec.lang = "en-US";
  rec.onresult = (e) => { $("text").value = e.results[0][0].transcript; send(); };
  $("mic").onclick = () => rec.start();
} else {
  $("mic").style.display = "none";
}

setInterval(refresh, 1200);
refresh();
